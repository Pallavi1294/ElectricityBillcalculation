//
//  ElectricityBillViewController.swift
//  ElectricityBillcalculation
//
//  Created by MacStudent on 2018-08-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ElectricityBillViewController: UIViewController, PassDataProtocol {

    
    var electricityBill: ElectricityBill?
    var viewDate: UIDatePicker?
    @IBOutlet weak var textField_Date: UITextField!
    
    
    //@IBOutlet weak var date: UIDatePicker!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtTotal: UITextField!
    @IBOutlet weak var seggender: UISegmentedControl!
    @IBOutlet weak var txtdate: UITextField!
    @IBAction func segend(_ sender: UISegmentedControl) {
        switch (seggender.selectedSegmentIndex) {
        case 0:
            electricityBill?.gender = "Male"
        case 1:
            electricityBill?.gender = "Female"
        default:
            break
        }
    }
    
    @IBOutlet weak var txtTotalUnit: UITextField!
    
    @IBOutlet weak var txtGender: UITextField!
    @IBOutlet weak var txtCustname: UITextField!
    @IBOutlet weak var txtCustid: UITextField!
    @IBOutlet weak var lbltotalAmount: UILabel!
    
    
   // @IBAction func btnTotal(_sender: Any) {
//electricityBill = ElectricityBill(customerId: Int(txtCustid.text!), customerName: txtCustname.text!, gender:Gender.MALE, billDate:, unitConsumed: Int(txtTotalUnit.text!), totalBillAmount: 0)
        
   // }
    
    @IBAction func btnTotalBill(_ sender: UIButton) {
        electricityBill = ElectricityBill(customerId: Int(txtCustid.text!), customerName: txtCustname.text!, gender: txtGender.text, billDate: txtdate.text!, unitConsumed: Int(txtTotalUnit.text!), totalBillAmount: 0, emailId: txtEmail.text!)
        
        performSegue(withIdentifier: "nv", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        viewDate = UIDatePicker()
        viewDate?.datePickerMode = .date
        viewDate?.addTarget(self, action: #selector(ElectricityBillViewController.dateChanged(datePicker:)),for: .valueChanged)
        txtdate.inputView = viewDate
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(getter: ElectricityBillViewController.view))
        

        // Do any additional setup after loading the view.
    }
    //@IBAction func btnTotalBill(_ sender: UIButton) {
        //performSegue(withIdentifier: "nv", sender: self)
   // }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
     
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destVC = segue.destination as? BillDetailViewController{
        destVC.electricityBill = electricityBill
            destVC.delegate = self
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        }
    }
    func setTotal(totalBill: Double)
    {
        print("A= \(totalBill)")
        self.electricityBill?.totalBillAmount = totalBill
        lbltotalAmount.isHidden = false
        lbltotalAmount.text = "Total Bill : $\(totalBill)"
    }
    @objc func dateChanged(datePicker: UIDatePicker){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        txtdate.text = String(dateFormatter.string(from: datePicker.date))
        view.endEditing(true)
    }
    @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer)  {
        view.endEditing(true)
    }
    
}

    


