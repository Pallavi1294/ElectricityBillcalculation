//
//  LoginViewController.swift
//  ElectricityBillcalculation
//
//  Created by MacStudent on 2018-08-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    
    
    @IBOutlet weak var switchRememberme: UISwitch!
    @IBOutlet weak var txtcustId: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    var userDefault: UserDefaults?
    
    @IBAction func btnLogin(_ sender: UIButton)
    
    {
        
        if txtcustId.text == "admin@a.com" && txtPassword.text == "admin123"
        {
            if switchRememberme.isOn
            {
                userDefault?.setValue(txtcustId.text, forKey: "email")
                userDefault?.set(txtPassword.text, forKey: "password")
            }
            else{
                userDefault?.removeObject(forKey: "email")
                userDefault?.removeObject(forKey: "password")
            }
            performSegue(withIdentifier: "showBillCalculationScreen", sender: self)
            print("Login Success", txtcustId.text!)
            
        }
        else{
            print("User Email / Password incorrect")
        }
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userDefault = UserDefaults.standard
        if let userId = userDefault?.value(forKey: "email"){
            if let userPassword = userDefault?.value(forKey: "passowrd"){
                txtcustId.text = userId as? String
                txtPassword.text = userPassword as? String
            }
        }
        
}
    
   
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
